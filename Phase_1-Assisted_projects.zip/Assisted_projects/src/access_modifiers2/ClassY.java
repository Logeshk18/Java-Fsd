package access_modifiers2;
import access_modifiers1.ClassN;

public class ClassY extends ClassN {
	
     public static void main(String[] args) {
			// TODO Auto-generated method stub
			new ClassZ().method_M();
			new ClassN().method_N();
			new ClassX().method_X();
		}

	}



