package binarySearch;
import java.util.Scanner;
public class Binary_search {

    public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		int i,n,temp,j;
		System.out.println("Enter no. of elements in the array");
		n=sc.nextInt();
		int arr[]=new int[n];
		System.out.println("Enter the elements");
		for (i=0;i<n;i++)
		{
			arr[i]=sc.nextInt();
		}
		int m=n;
		for(i=0;i<m;i++)
		{
			for(j=0;j<n-1;j++)
			{
				if(arr[j]>arr[j+1])
				{
					temp=arr[j+1];
					arr[j+1]=arr[j];
					arr[j]=temp;
				}
			}
			--n;
		}
		System.out.println("Enter the element to be searched");
		int a=sc.nextInt();
		int r,l,M;
		r=0;l=m-1;
		M=(l+r)/2;
		while(r<=l)
		{
			if(arr[M]==a)
			{
				System.out.println("Element found");
				break;
			}
			else if(arr[M]>a)
			{
				l=M-1;
			}
			else
			{
				r=M+1;
			}
			M=(r+l)/2;
		}
		if(r>l)
		{
			System.out.println("Element not found");
		}
		sc.close();

	}

}