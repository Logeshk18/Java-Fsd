package expo_search;
import java.util.Scanner;
public class Expo_search {
 
	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("  Exponential Search ");
		System.out.println("\nEnter no. of elements in the array");
		int i,n,j,temp,m,r,l,E;;
		n=sc.nextInt();
		int[] arr=new int[n];
		System.out.println("Enter the elements");
		for (i=0;i<n;i++)
		{
			arr[i]=sc.nextInt();
		}
		for(i=0;i<n;i++)
		{
			j=i+1;m=i;
			temp=arr[i];
			while(j<n)
 	        {
 	        	if(arr[j]<arr[i] && arr[j]<temp)
 	        	{
 	        		temp=arr[j];
 	        		m=j;
 	        	}
 	        	++j;
 	        }
			if(m==i)
			{
				continue;
			}
			else
			{
				arr[m]=arr[i];
				arr[i]=temp;
			}
		}
		System.out.println("Enter the element to be searched");
		int a=sc.nextInt();
		if(a<arr[0] || a>arr[n-1])
		{
			System.out.println("Element not found");
		}
		else
		{
			if(arr[0]==a)
			{
				System.out.println("Element found");
			}
			else
			{
				i=1;
				while(i<n)
				{
					if(arr[i]==a)
					{
						System.out.println("Element found");
						break;
					}
					else
					{
						if(a>arr[i] && (i*2)<n && a<arr[i*2])
						{
							r=i;
							l=r*2;
							E=(l+r)/2;
							while(r<=l)
							{
								if(arr[E]==a)
								{
									System.out.println("Element found");
									break;
								}
								else if(arr[E]>a)
								{
									l=E-1;
								}
								else
								{
									r=E+1;
								}
								E=(r+l)/2;
							}
							if(r>l)
							{
								System.out.println("Element not found");
							}
							break;
						}
						i=i*2;
					}
				}
			
			}
		}
		sc.close();

	}

}
