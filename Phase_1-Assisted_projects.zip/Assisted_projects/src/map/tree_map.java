package map;
import java.util.*;

public class tree_map {

     public static void main(String[] args) {
	
		int a,t;
		String s;
		Scanner sc=new Scanner(System.in);
		
		//Tree Map
		Map<Integer,String> TM=new TreeMap<>();
		System.out.println("Enter no. of strings to be added");
		a=sc.nextInt();
		System.out.println("Enter " + a + " key+String");
		for(int i=0;i<a;i++)
		{
			t=sc.nextInt();
			s=sc.next();
			TM.put(t,s);
		}
		System.out.println(TM);
		sc.close();

	}

}