package selection_sort;
import java.util.Scanner;
public class Selection_sort {

    public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("   Selection Sort ");
		System.out.println("\nEnter no. of elements in the array");
		int i,n,j,temp,m;
		n=sc.nextInt();
		int[] arr=new int[n];
		System.out.println("Enter the elements");
		for (i=0;i<n;i++)
		{
			arr[i]=sc.nextInt();
		}
		for(i=0;i<n;i++)
		{
			j=i+1;m=i;
			temp=arr[i];
			while(j<n)
 	        {
 	        	if(arr[j]<arr[i] && arr[j]<temp)
 	        	{
 	        		temp=arr[j];
 	        		m=j;
 	        	}
 	        	++j;
 	        }
			if(m==i)
			{
				continue;
			}
			else
			{
				arr[m]=arr[i];
				arr[i]=temp;
			}
		}
		System.out.print("Sorted elements : ");
		for(i=0;i<n;i++)
		{
			System.out.print(arr[i] + " ");
		}
		sc.close();

	}

}