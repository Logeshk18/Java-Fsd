package threads;

class ThreadDemo extends Thread implements Runnable {
	
	public void run()
	{
		System.out.println(" HEY Thread ! \n");
	}
}

public class Threads {

	public static void main(String[] args) {
		
		//Thread class
		ThreadDemo T1=new ThreadDemo();
		T1.start();
		
		//Runnable Interface
		ThreadDemo tR=new ThreadDemo();
		Thread t=new Thread(tR);
		t.start();

	}

}
