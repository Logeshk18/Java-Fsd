package com;

import java.io.IOException;
import data_transfer_objects.*;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class FirstServlet
 */
public class FirstServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String name = request.getParameter("name");
		String email = request.getParameter("email");
		System.out.println(name);
		
		HttpSession session = request.getSession(); //creates a new session
		User user = new User();
		
		if(session != null) {
			user.setName(name);
			user.setEmail(email);
			
			//creating a name and value for session
			session.setAttribute("user", user);
			
			//redirecting to next page
			response.sendRedirect("two.html");
		}
	}

}
