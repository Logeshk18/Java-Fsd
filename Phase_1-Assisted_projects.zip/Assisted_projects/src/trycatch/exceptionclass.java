package trycatch;

public class exceptionclass {

    public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a,b,c;
		a = 10;
		b = 0;
		try {
			c= a/b; 
			System.out.println("the value is ;"+c);
		}
		catch(ArithmeticException ae){
			System.out.println("Number cannot be divided by zero");
			System.out.println(ae.getMessage());
		
		}
        finally{
        	System.out.println("Addition is :"+ (a+b));
        	
        }
	}

}
