package com;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class LoginServlet
 */
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String name = request.getParameter("name");
		
		
		RequestDispatcher rd; 
		if(name.equals("nandha")) {
			
			//creating new cookie
			Cookie cookie = new Cookie("name", name);
			
			response.addCookie(cookie);
			
			rd = request.getRequestDispatcher("links.html");
			rd.forward(request, response);
		}else {
			PrintWriter out = response.getWriter();
			out.print("<span><p style='color:red'>Invalid Name</p></span>");
			
			rd = request.getRequestDispatcher("login.html");
			rd.include(request, response);
		}
	}

}
