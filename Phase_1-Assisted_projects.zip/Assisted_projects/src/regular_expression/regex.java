package regular_expression;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class regex {

	public static void main(String[] args)
{
		Pattern p=Pattern.compile("day");
		Matcher m=p.matcher("Today is a good day");
		Boolean a=m.find();
		System.out.println(a); 
		
		Pattern p1=Pattern.compile("[A-D]");
		Matcher m1=p1.matcher("B");
		Boolean a1=m1.matches();
		System.out.println(a1);
		
		Pattern p2 = Pattern.compile("Hello");
		Matcher m2 = p2.matcher("you are nice");
		Boolean a2 = m2.matches();
		System.out.println(a2);
		
		

} }
