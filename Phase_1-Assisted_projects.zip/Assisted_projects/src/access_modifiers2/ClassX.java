package access_modifiers2;

public class ClassX {
	private int i=23;
	long l=352353;
	protected float f=(float)5536.34;
	public char c='a';
	protected void method_X(){
		System.out.println("\nwe are in class X");
		System.out.println("value of i "+i);
		System.out.println("value of l "+l);
		System.out.println("value of f "+f);
		System.out.println("value of c "+c);
	}
}


