package com;
import java.sql.*;

public class DBConnector {
	
	static Connection con;
	
	public static Connection getConnection() {
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			
			String dbUrl = "jdbc:mysql://localhost:3306/practice";
			String user = "root";
			String pwd = "123456";
			
			con = DriverManager.getConnection(dbUrl, user, pwd);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return con;
	}
}
