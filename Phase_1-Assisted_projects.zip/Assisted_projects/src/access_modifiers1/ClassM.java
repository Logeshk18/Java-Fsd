package access_modifiers1;

public class ClassM {
	
	    private int i=5;
		long l=23442343;
		protected float f=3.3f;
		public void method_M()
		{
			System.out.println("we are in class M");
			System.out.println("value of i "+i);
			System.out.println("value of l "+l);
			System.out.println("value of f "+f);
		}
	}


