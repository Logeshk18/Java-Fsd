package access_modifiers1;

public class ClassP {
	
	public static void main(String[] args) {
			// TODO Auto-generated method stub
			new ClassM().method_M();
			new ClassN().method_N();
		}

	}



