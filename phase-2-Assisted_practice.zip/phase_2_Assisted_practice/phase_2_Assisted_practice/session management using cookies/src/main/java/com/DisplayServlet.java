package com;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class DisplayServlet
 */
public class DisplayServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		response.setContentType("text/html;charset=UTF-8");

		Cookie cookies[] = request.getCookies();

		PrintWriter out = response.getWriter();

		if(cookies != null) {
			out.println("The cookies information are");
			for(Cookie cookie: cookies) {
				out.println("Cookie.name: "+ cookie.getValue());
			}

			out.println("<a href='links.html'>links page</a>");
		}
	}
}


