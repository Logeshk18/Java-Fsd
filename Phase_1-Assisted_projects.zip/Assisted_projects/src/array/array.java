package array;
import java.util.Scanner;
public class array {
public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n,temp=0;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the size of the array");
		n=sc.nextInt();
		int ar[]=new int[n];
		System.out.println("enter the elements");
		for(int i=0;i<n;i++){
			ar[i]=sc.nextInt();
		}
		for(int i=0;i<ar.length;i++){
			temp=temp+ar[i];
		}
		System.out.println("sum of the array is " +temp);
        sc.close();
	}
}
