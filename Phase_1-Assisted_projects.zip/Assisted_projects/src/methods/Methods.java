package methods;

public class Methods {

	public int calculate(int a,int b)
	{
		return (int)(a+b);
	}
	public int calculate(int a)
	{
		int c = (22/7)*(a*a);
		return c;
	}
	public int calculate(double a,double b)
	{
		int c =(int)(a*b);
		return c;
	}
	public float subtraction(float a , float b )
	{ float c= a-b;
	   return c;
	  
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Methods m=new Methods();
		//method overloading
		int a=m.calculate(4,6);
		int b=m.calculate(4);
		int c=m.calculate(3.4,5);
		//normal method calling
		float d=m.subtraction(3,2);
		
		System.out.println(a);
		System.out.println(b);
		System.out.println(c);
		System.out.println(d);
		
		

	}

}
