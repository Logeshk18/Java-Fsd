package map;
import java.util.*;
  
 public class hashmap {

  public static void main(String[] args) {
	
		int n,h;
		String s;
		Scanner sc=new Scanner(System.in);
		
		//Hash Map
		Map<Integer,String> HM=new HashMap<>();
		System.out.println("Enter no. of strings to be added");
		n=sc.nextInt();
		System.out.println("Enter " + n + " key+String");
		for(int a=0;a<n;a++)
		{
			h=sc.nextInt();
			s=sc.next();
			HM.put(h,s);
		}
		System.out.println(HM);
		sc.close();
}
  }