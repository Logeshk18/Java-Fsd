package typecasting;

public class typecasting {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        System.out.println("Explicit typecasting");
		float f=5.2f;
		System.out.println("float:" + f);
		long lg= (long)(f);
		System.out.println("Float --> long: " + lg); 
		
		double d=70.2;
		System.out.println("double :" + d);
		char c=(char) (int) (long) d;
		System.out.println("Double --> Long --> Int --> Char: " + c);
		
		long lg1=66825574;
		byte bt=(byte) lg1;
		System.out.println("Long --> Byte: " + bt);
        System.out.println();
		
		
        System.out.println("implicit typecasting");
        int x = 34;
        System.out.println("int:" +x);
        long lg3=x;
        System.out.println("int --> long :" + lg3);
        double d2 = lg3;
        System.out.println("long --> double ;" + d2);
        
        
		
			}
		}

	


