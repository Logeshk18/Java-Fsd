package access_modifiers2;
import access_modifiers1.ClassM;
import access_modifiers1.ClassN;
  
public class ClassZ extends ClassM {

		public static void main(String[] args) {
			// TODO Auto-generated method stub
			new ClassM().method_M();
			new ClassN().method_N();
			new ClassX().method_X();

		}

}
