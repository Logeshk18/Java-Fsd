package strings;

public class string_convert {

	public static void main(String[] args)
	{
		String s1 = "Java_phase1";
		StringBuffer s2 = new StringBuffer(s1);
		StringBuilder s3 = new StringBuilder(s1);
		
		System.out.println("String : "+s1);
		System.out.println("String Buffer : "+s2);
		System.out.println("String Builder : "+s3);

	}
}