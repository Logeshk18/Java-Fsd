package data_transfer_objects;

public class User {
	private String name;
	private String email;
	private int age;
	private long contact;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public long getContact() {
		return contact;
	}
	public void setContact(long contact) {
		this.contact = contact;
	}
	@Override
	public String toString() {
		return "User [" + (name != null ? "name=" + name + ", " : "") + (email != null ? "email=" + email + ", " : "")
				+ "age=" + age + ", contact=" + contact + "]";
	}
	
	
}
