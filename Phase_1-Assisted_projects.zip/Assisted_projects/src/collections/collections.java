package collections;
import java.util.*;

public class collections {

	public static void main(String[] args) {
		
		//Array List
		int a,b;
		List <Integer> arr=new ArrayList<Integer>();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter no. of elements in arraylist:");
        a=sc.nextInt();
        System.out.println("Enter the elements to be added in arraylist");
        for(int i=0;i<a;i++)
        {
        	b=sc.nextInt();
        	arr.add(b);
        }
        System.out.println(arr);
        
        //Vector
        List <Integer> vector=new Vector<Integer>();
        System.out.println("Enter no. of elements in vector:");
        a=sc.nextInt();
        System.out.println("Enter the elements to be added in vector");
        for(int i=0;i<a;i++)
        {
        	b=sc.nextInt();
        	vector.add(b);
        }
        System.out.println(vector);
        
        //Hash Set
        char c;
        Set <Character> hash=new HashSet<Character>();
		System.out.println("Enter no. of characters in hashset:");
        a=sc.nextInt();
        System.out.println("Enter the characters to be added in hashset");
        for(int i=0;i<a;i++)
        {
        	c=sc.next().charAt(0);
        	hash.add(c);
        }
        System.out.println(hash);
       
        //Linked List
        String str;
        List <String> link=new LinkedList<String>();
		System.out.println("Enter no. of strings in linkedlist :");
        a=sc.nextInt();
        System.out.println("Enter the strings to be added to the Linkedlist ");
        for(int i=0;i<a;i++)
        {
        	str=sc.nextLine();
        	link.add(str);
        }
        System.out.println(link);
        
        sc.close();
	}

}