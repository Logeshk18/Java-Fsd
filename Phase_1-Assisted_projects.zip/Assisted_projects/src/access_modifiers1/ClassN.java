package access_modifiers1;

public class ClassN {
	
    protected long l=5675467;
	public int i=34;
	double d=45234;
	public void method_N()
	{
		System.out.println("\nwe are in class N");
		System.out.println("value of l "+l);
		System.out.println("value of i "+i);
		System.out.println("value of d "+d);
	}
}


