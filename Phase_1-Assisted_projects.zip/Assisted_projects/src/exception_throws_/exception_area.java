package exception_throws_;
import java.io.IOException;
import java.util.Scanner;
 
public class exception_area {

	    void display(int l,int b) throws IOException
	    {
	    	if(l>b)
	    	{
	    		throw new IOException();
	    	}
	    	else
	    	{
	    		System.out.println("Area of Rectangle= " + (l*b));
	    	}
	    }
	    void  n(int a,int b)
	    {
	    	try
	    	{
	    	    display(a,b);
	    	}
	    	catch(Exception e)
	    	{
	    		System.out.println("IOException");
	    	}
	    	finally
	    	{
	    		System.out.println("Finally block is executed");
	    	}
	    }
		public static void main(String[] args) {
			
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter the length and breadth of Rectangle");
			int a=sc.nextInt();
			int b=sc.nextInt();
			exception_area obj=new exception_area();
			obj.n(a, b);
			sc.close();
		}

	}