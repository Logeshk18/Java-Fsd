package bubble_sort;
import java.util.Scanner;
public class Bubble_sort {

  public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("   Bubble Sort ");
		System.out.println("\nEnter no. of elements in the array");
		int i,n,j,temp;
		n=sc.nextInt();
		int[] arr=new int[n];
		System.out.println("Enter the elements");
		for (i=0;i<n;i++)
		{
			arr[i]=sc.nextInt();
		}
		int m=n;
		for(i=0;i<n;i++)
		{
			for(j=0;j<m-1;j++)
			{
				if(arr[j]>arr[j+1])
				{
					temp=arr[j+1];
					arr[j+1]=arr[j];
					arr[j]=temp;
				}
			}
			--m;
		}
		System.out.print("Sorted elements : ");
		for(i=0;i<n;i++)
		{
			System.out.print(arr[i] + " ");
		}
		sc.close();

	}

}